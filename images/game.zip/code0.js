gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDJumpButtonObjects1_1final = [];

gdjs.Game_32SceneCode.GDBackgroundObjects1= [];
gdjs.Game_32SceneCode.GDBackgroundObjects2= [];
gdjs.Game_32SceneCode.GDBackgroundObjects3= [];
gdjs.Game_32SceneCode.GDDistance_9595UITextObjects1= [];
gdjs.Game_32SceneCode.GDDistance_9595UITextObjects2= [];
gdjs.Game_32SceneCode.GDDistance_9595UITextObjects3= [];
gdjs.Game_32SceneCode.GDBoundary_9595RightObjects1= [];
gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2= [];
gdjs.Game_32SceneCode.GDBoundary_9595RightObjects3= [];
gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1= [];
gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects2= [];
gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects3= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects1= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects2= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects3= [];
gdjs.Game_32SceneCode.GDCameraObjects1= [];
gdjs.Game_32SceneCode.GDCameraObjects2= [];
gdjs.Game_32SceneCode.GDCameraObjects3= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects3= [];
gdjs.Game_32SceneCode.GDHazardObjects1= [];
gdjs.Game_32SceneCode.GDHazardObjects2= [];
gdjs.Game_32SceneCode.GDHazardObjects3= [];
gdjs.Game_32SceneCode.GDPlatform_9595FloatingObjects1= [];
gdjs.Game_32SceneCode.GDPlatform_9595FloatingObjects2= [];
gdjs.Game_32SceneCode.GDPlatform_9595FloatingObjects3= [];
gdjs.Game_32SceneCode.GDPlayerObjects1= [];
gdjs.Game_32SceneCode.GDPlayerObjects2= [];
gdjs.Game_32SceneCode.GDPlayerObjects3= [];
gdjs.Game_32SceneCode.GD_9595_9595tempObjects1= [];
gdjs.Game_32SceneCode.GD_9595_9595tempObjects2= [];
gdjs.Game_32SceneCode.GD_9595_9595tempObjects3= [];
gdjs.Game_32SceneCode.GDBuildingObjects1= [];
gdjs.Game_32SceneCode.GDBuildingObjects2= [];
gdjs.Game_32SceneCode.GDBuildingObjects3= [];
gdjs.Game_32SceneCode.GDNeonLight_9595MagentaObjects1= [];
gdjs.Game_32SceneCode.GDNeonLight_9595MagentaObjects2= [];
gdjs.Game_32SceneCode.GDNeonLight_9595MagentaObjects3= [];
gdjs.Game_32SceneCode.GDNeonLight_9595CyanObjects1= [];
gdjs.Game_32SceneCode.GDNeonLight_9595CyanObjects2= [];
gdjs.Game_32SceneCode.GDNeonLight_9595CyanObjects3= [];
gdjs.Game_32SceneCode.GDCoinObjects1= [];
gdjs.Game_32SceneCode.GDCoinObjects2= [];
gdjs.Game_32SceneCode.GDCoinObjects3= [];
gdjs.Game_32SceneCode.GDTramObjects1= [];
gdjs.Game_32SceneCode.GDTramObjects2= [];
gdjs.Game_32SceneCode.GDTramObjects3= [];
gdjs.Game_32SceneCode.GDCarObjects1= [];
gdjs.Game_32SceneCode.GDCarObjects2= [];
gdjs.Game_32SceneCode.GDCarObjects3= [];
gdjs.Game_32SceneCode.GDBusObjects1= [];
gdjs.Game_32SceneCode.GDBusObjects2= [];
gdjs.Game_32SceneCode.GDBusObjects3= [];
gdjs.Game_32SceneCode.GDShieldPowerupObjects1= [];
gdjs.Game_32SceneCode.GDShieldPowerupObjects2= [];
gdjs.Game_32SceneCode.GDShieldPowerupObjects3= [];
gdjs.Game_32SceneCode.GDMagnetPowerupObjects1= [];
gdjs.Game_32SceneCode.GDMagnetPowerupObjects2= [];
gdjs.Game_32SceneCode.GDMagnetPowerupObjects3= [];
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1= [];
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects2= [];
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects3= [];
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1= [];
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects2= [];
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects3= [];
gdjs.Game_32SceneCode.GDCoins_9595UITextObjects1= [];
gdjs.Game_32SceneCode.GDCoins_9595UITextObjects2= [];
gdjs.Game_32SceneCode.GDCoins_9595UITextObjects3= [];
gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1= [];
gdjs.Game_32SceneCode.GDStatus_9595UITextObjects2= [];
gdjs.Game_32SceneCode.GDStatus_9595UITextObjects3= [];
gdjs.Game_32SceneCode.GDRock_95952Objects1= [];
gdjs.Game_32SceneCode.GDRock_95952Objects2= [];
gdjs.Game_32SceneCode.GDRock_95952Objects3= [];
gdjs.Game_32SceneCode.GDRock_95955Objects1= [];
gdjs.Game_32SceneCode.GDRock_95955Objects2= [];
gdjs.Game_32SceneCode.GDRock_95955Objects3= [];
gdjs.Game_32SceneCode.GDRock_95953Objects1= [];
gdjs.Game_32SceneCode.GDRock_95953Objects2= [];
gdjs.Game_32SceneCode.GDRock_95953Objects3= [];
gdjs.Game_32SceneCode.GDRock_95956Objects1= [];
gdjs.Game_32SceneCode.GDRock_95956Objects2= [];
gdjs.Game_32SceneCode.GDRock_95956Objects3= [];
gdjs.Game_32SceneCode.GDRock_95951Objects1= [];
gdjs.Game_32SceneCode.GDRock_95951Objects2= [];
gdjs.Game_32SceneCode.GDRock_95951Objects3= [];
gdjs.Game_32SceneCode.GDRock_95954Objects1= [];
gdjs.Game_32SceneCode.GDRock_95954Objects2= [];
gdjs.Game_32SceneCode.GDRock_95954Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95955Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95955Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95955Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95951Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95951Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95951Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95952Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95952Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95952Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95954Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95954Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95954Objects3= [];
gdjs.Game_32SceneCode.GDRock_95957Objects1= [];
gdjs.Game_32SceneCode.GDRock_95957Objects2= [];
gdjs.Game_32SceneCode.GDRock_95957Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95953Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95953Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95953Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95954Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95954Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95954Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95953Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95953Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95953Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95951Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95951Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95951Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95957Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95957Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95957Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95956Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95956Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Moss_95956Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95952Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95952Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95952Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95955Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95955Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95955Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95957Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95957Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95957Objects3= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95956Objects1= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95956Objects2= [];
gdjs.Game_32SceneCode.GDRock_9595Snow_95956Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95951Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95951Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95951Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95952Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95952Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95952Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95954Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95954Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95954Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95952Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95952Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95952Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95955Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95955Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95955Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95953Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95953Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_95953Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95951Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95951Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95951Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95953Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95953Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95953Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95954Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95954Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95954Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95951Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95951Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95951Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95955Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95955Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95955Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95952Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95952Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95952Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95953Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95953Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95953Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95954Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95954Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95954Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95951Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95951Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95951Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95954Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95954Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95954Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95952Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95952Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95952Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95955Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95955Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95955Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95955Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95955Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95955Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95953Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95953Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95953Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95951Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95951Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95951Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95952Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95952Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95952Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95953Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95953Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95953Objects3= [];
gdjs.Game_32SceneCode.GDBush_95951Objects1= [];
gdjs.Game_32SceneCode.GDBush_95951Objects2= [];
gdjs.Game_32SceneCode.GDBush_95951Objects3= [];
gdjs.Game_32SceneCode.GDBush_95952Objects1= [];
gdjs.Game_32SceneCode.GDBush_95952Objects2= [];
gdjs.Game_32SceneCode.GDBush_95952Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95955Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95955Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95955Objects3= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95954Objects1= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95954Objects2= [];
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95954Objects3= [];
gdjs.Game_32SceneCode.GDBush_9595Snow_95952Objects1= [];
gdjs.Game_32SceneCode.GDBush_9595Snow_95952Objects2= [];
gdjs.Game_32SceneCode.GDBush_9595Snow_95952Objects3= [];
gdjs.Game_32SceneCode.GDBush_9595Berries_95951Objects1= [];
gdjs.Game_32SceneCode.GDBush_9595Berries_95951Objects2= [];
gdjs.Game_32SceneCode.GDBush_9595Berries_95951Objects3= [];
gdjs.Game_32SceneCode.GDBush_9595Berries_95952Objects1= [];
gdjs.Game_32SceneCode.GDBush_9595Berries_95952Objects2= [];
gdjs.Game_32SceneCode.GDBush_9595Berries_95952Objects3= [];
gdjs.Game_32SceneCode.GDCactus_95951Objects1= [];
gdjs.Game_32SceneCode.GDCactus_95951Objects2= [];
gdjs.Game_32SceneCode.GDCactus_95951Objects3= [];
gdjs.Game_32SceneCode.GDBush_9595Snow_95951Objects1= [];
gdjs.Game_32SceneCode.GDBush_9595Snow_95951Objects2= [];
gdjs.Game_32SceneCode.GDBush_9595Snow_95951Objects3= [];
gdjs.Game_32SceneCode.GDCactus_95952Objects1= [];
gdjs.Game_32SceneCode.GDCactus_95952Objects2= [];
gdjs.Game_32SceneCode.GDCactus_95952Objects3= [];
gdjs.Game_32SceneCode.GDCactus_95955Objects1= [];
gdjs.Game_32SceneCode.GDCactus_95955Objects2= [];
gdjs.Game_32SceneCode.GDCactus_95955Objects3= [];
gdjs.Game_32SceneCode.GDCactus_95953Objects1= [];
gdjs.Game_32SceneCode.GDCactus_95953Objects2= [];
gdjs.Game_32SceneCode.GDCactus_95953Objects3= [];
gdjs.Game_32SceneCode.GDCactus_95954Objects1= [];
gdjs.Game_32SceneCode.GDCactus_95954Objects2= [];
gdjs.Game_32SceneCode.GDCactus_95954Objects3= [];
gdjs.Game_32SceneCode.GDCactus_9595Flower_95951Objects1= [];
gdjs.Game_32SceneCode.GDCactus_9595Flower_95951Objects2= [];
gdjs.Game_32SceneCode.GDCactus_9595Flower_95951Objects3= [];
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95953Objects1= [];
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95953Objects2= [];
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95953Objects3= [];
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95952Objects1= [];
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95952Objects2= [];
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95952Objects3= [];
gdjs.Game_32SceneCode.GDDetail_9595Awning_9595WideObjects1= [];
gdjs.Game_32SceneCode.GDDetail_9595Awning_9595WideObjects2= [];
gdjs.Game_32SceneCode.GDDetail_9595Awning_9595WideObjects3= [];
gdjs.Game_32SceneCode.GDDetail_9595UmbrellaObjects1= [];
gdjs.Game_32SceneCode.GDDetail_9595UmbrellaObjects2= [];
gdjs.Game_32SceneCode.GDDetail_9595UmbrellaObjects3= [];
gdjs.Game_32SceneCode.GDDetail_9595Umbrella_9595DetailedObjects1= [];
gdjs.Game_32SceneCode.GDDetail_9595Umbrella_9595DetailedObjects2= [];
gdjs.Game_32SceneCode.GDDetail_9595Umbrella_9595DetailedObjects3= [];
gdjs.Game_32SceneCode.GDDetail_9595OverhangObjects1= [];
gdjs.Game_32SceneCode.GDDetail_9595OverhangObjects2= [];
gdjs.Game_32SceneCode.GDDetail_9595OverhangObjects3= [];
gdjs.Game_32SceneCode.GDDetail_9595Overhang_9595WideObjects1= [];
gdjs.Game_32SceneCode.GDDetail_9595Overhang_9595WideObjects2= [];
gdjs.Game_32SceneCode.GDDetail_9595Overhang_9595WideObjects3= [];
gdjs.Game_32SceneCode.GDDetail_9595AwningObjects1= [];
gdjs.Game_32SceneCode.GDDetail_9595AwningObjects2= [];
gdjs.Game_32SceneCode.GDDetail_9595AwningObjects3= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595CObjects1= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595CObjects2= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595CObjects3= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595BObjects1= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595BObjects2= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595BObjects3= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595FObjects1= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595FObjects2= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595FObjects3= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595EObjects1= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595EObjects2= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595EObjects3= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595DObjects1= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595DObjects2= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595DObjects3= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595AObjects1= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595AObjects2= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595AObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595CObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595CObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595CObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595DObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595DObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595DObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595EObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595EObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595EObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595BObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595BObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595BObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595AObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595AObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595AObjects3= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595GObjects1= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595GObjects2= [];
gdjs.Game_32SceneCode.GDLarge_9595Building_9595GObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595FObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595FObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595FObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595HObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595HObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595HObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595KObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595KObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595KObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595IObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595IObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595IObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595GObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595GObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595GObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595JObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595JObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595JObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595LObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595LObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595LObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595MObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595MObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595MObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595NObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595NObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Building_9595NObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Wide_9595BObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Wide_9595BObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Wide_9595BObjects3= [];
gdjs.Game_32SceneCode.GDRoof_9595CenterObjects1= [];
gdjs.Game_32SceneCode.GDRoof_9595CenterObjects2= [];
gdjs.Game_32SceneCode.GDRoof_9595CenterObjects3= [];
gdjs.Game_32SceneCode.GDLow_9595Wide_9595AObjects1= [];
gdjs.Game_32SceneCode.GDLow_9595Wide_9595AObjects2= [];
gdjs.Game_32SceneCode.GDLow_9595Wide_9595AObjects3= [];
gdjs.Game_32SceneCode.GDRoof_9595CornerObjects1= [];
gdjs.Game_32SceneCode.GDRoof_9595CornerObjects2= [];
gdjs.Game_32SceneCode.GDRoof_9595CornerObjects3= [];
gdjs.Game_32SceneCode.GDRoof_9595OverhangObjects1= [];
gdjs.Game_32SceneCode.GDRoof_9595OverhangObjects2= [];
gdjs.Game_32SceneCode.GDRoof_9595OverhangObjects3= [];
gdjs.Game_32SceneCode.GDRoof_9595SideObjects1= [];
gdjs.Game_32SceneCode.GDRoof_9595SideObjects2= [];
gdjs.Game_32SceneCode.GDRoof_9595SideObjects3= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595BObjects1= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595BObjects2= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595BObjects3= [];
gdjs.Game_32SceneCode.GDSign_9595BillboardObjects1= [];
gdjs.Game_32SceneCode.GDSign_9595BillboardObjects2= [];
gdjs.Game_32SceneCode.GDSign_9595BillboardObjects3= [];
gdjs.Game_32SceneCode.GDSign_9595HospitalObjects1= [];
gdjs.Game_32SceneCode.GDSign_9595HospitalObjects2= [];
gdjs.Game_32SceneCode.GDSign_9595HospitalObjects3= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595DObjects1= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595DObjects2= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595DObjects3= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595CObjects1= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595CObjects2= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595CObjects3= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595FObjects1= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595FObjects2= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595FObjects3= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595CObjects1= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595CObjects2= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595CObjects3= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595BObjects1= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595BObjects2= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595BObjects3= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595EObjects1= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595EObjects2= [];
gdjs.Game_32SceneCode.GDSkyscraper_9595EObjects3= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595AObjects1= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595AObjects2= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595AObjects3= [];
gdjs.Game_32SceneCode.GDWall_9595Door_9595AObjects1= [];
gdjs.Game_32SceneCode.GDWall_9595Door_9595AObjects2= [];
gdjs.Game_32SceneCode.GDWall_9595Door_9595AObjects3= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595DObjects1= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595DObjects2= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595DObjects3= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595EObjects1= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595EObjects2= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595EObjects3= [];
gdjs.Game_32SceneCode.GDWall_9595SolidObjects1= [];
gdjs.Game_32SceneCode.GDWall_9595SolidObjects2= [];
gdjs.Game_32SceneCode.GDWall_9595SolidObjects3= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595FObjects1= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595FObjects2= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595FObjects3= [];
gdjs.Game_32SceneCode.GDWall_9595Door_9595BObjects1= [];
gdjs.Game_32SceneCode.GDWall_9595Door_9595BObjects2= [];
gdjs.Game_32SceneCode.GDWall_9595Door_9595BObjects3= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595BObjects1= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595BObjects2= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595BObjects3= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595AObjects1= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595AObjects2= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595AObjects3= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595DObjects1= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595DObjects2= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595DObjects3= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595CObjects1= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595CObjects2= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595CObjects3= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595FObjects1= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595FObjects2= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595FObjects3= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595EObjects1= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595EObjects2= [];
gdjs.Game_32SceneCode.GDWall_9595Window_9595EObjects3= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595B2Objects1= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595B2Objects2= [];
gdjs.Game_32SceneCode.GDSmall_9595Building_9595B2Objects3= [];


gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCameraObjects1Objects = Hashtable.newFrom({"Camera": gdjs.Game_32SceneCode.GDCameraObjects1});
gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayerObjects1[k] = gdjs.Game_32SceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].addForce(180, 200, 0);
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCarObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDTramObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDBusObjects1Objects = Hashtable.newFrom({"Car": gdjs.Game_32SceneCode.GDCarObjects1, "Tram": gdjs.Game_32SceneCode.GDTramObjects1, "Bus": gdjs.Game_32SceneCode.GDBusObjects1});
gdjs.Game_32SceneCode.asyncCallback15214988 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
gdjs.Game_32SceneCode.localVariables.length = 0;
}
gdjs.Game_32SceneCode.idToCallbackMap.set(15214988, gdjs.Game_32SceneCode.asyncCallback15214988);
gdjs.Game_32SceneCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Game_32SceneCode.asyncCallback15214988(runtimeScene, asyncObjectsList)), 15214988, asyncObjectsList);
}
}

}


};gdjs.Game_32SceneCode.eventsList2 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{isConditionTrue_1 = runtimeScene.getScene().getVariables().getFromIndex(5).getAsBoolean();
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDBusObjects1, gdjs.Game_32SceneCode.GDBusObjects2);

gdjs.copyArray(gdjs.Game_32SceneCode.GDCarObjects1, gdjs.Game_32SceneCode.GDCarObjects2);

gdjs.copyArray(gdjs.Game_32SceneCode.GDTramObjects1, gdjs.Game_32SceneCode.GDTramObjects2);

{for(var i = 0, len = gdjs.Game_32SceneCode.GDCarObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCarObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Game_32SceneCode.GDTramObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTramObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Game_32SceneCode.GDBusObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBusObjects2[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(3).getAsBoolean();
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDBusObjects1, gdjs.Game_32SceneCode.GDBusObjects2);

gdjs.copyArray(gdjs.Game_32SceneCode.GDCarObjects1, gdjs.Game_32SceneCode.GDCarObjects2);

gdjs.copyArray(gdjs.Game_32SceneCode.GDTramObjects1, gdjs.Game_32SceneCode.GDTramObjects2);

{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "GraceTimer");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCarObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCarObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Game_32SceneCode.GDTramObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTramObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Game_32SceneCode.GDBusObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBusObjects2[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/StartingCollision.wav", false, 90, gdjs.randomFloatInRange(0.7, 0.9));
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("ShakeModel3D").Shake(2, 0, 0, null);
}
}
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 2, 0, 0, null);
}
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.025);
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList1(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects2Objects = Hashtable.newFrom({"Platform_Ground": gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects2Objects = Hashtable.newFrom({"Platform_Ground": gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1});
gdjs.Game_32SceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Boundary_Right"), gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1, gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects2Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects2Objects, (( gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2[0].getPointX("")), (( gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2[0].getPointY("")), false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2 */
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber((( gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2[0].getAABBRight()));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects1Objects) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boundary_Right"), gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1, gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2);

{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2[i].setX((( gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2[0].getPointX("")));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects1Objects) > 0;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1[i].setX(gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCarObjects2Objects = Hashtable.newFrom({"Car": gdjs.Game_32SceneCode.GDCarObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDTramObjects2Objects = Hashtable.newFrom({"Tram": gdjs.Game_32SceneCode.GDTramObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBusObjects2Objects = Hashtable.newFrom({"Bus": gdjs.Game_32SceneCode.GDBusObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCarObjects2Objects = Hashtable.newFrom({"Car": gdjs.Game_32SceneCode.GDCarObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDTramObjects2Objects = Hashtable.newFrom({"Tram": gdjs.Game_32SceneCode.GDTramObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBusObjects1Objects = Hashtable.newFrom({"Bus": gdjs.Game_32SceneCode.GDBusObjects1});
gdjs.Game_32SceneCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[1].getFromIndex(0).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDCarObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCarObjects2Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getX()) + 3260, 480, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCarObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCarObjects2[i].getBehavior("Object3D").setZ(64);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[1].getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDTramObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDTramObjects2Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getX()) + 3260, 470, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTramObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTramObjects2[i].getBehavior("Object3D").setZ(64);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[1].getFromIndex(0).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.Game_32SceneCode.GDBusObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBusObjects1Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) + 3260, 475, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBusObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBusObjects1[i].getBehavior("Object3D").setZ(64);
}
}
}

}


};gdjs.Game_32SceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDCarObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCarObjects2Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getX()) + 3000, 480, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCarObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCarObjects2[i].getBehavior("Object3D").setZ(64);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDTramObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDTramObjects2Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getX()) + 3000, 470, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTramObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTramObjects2[i].getBehavior("Object3D").setZ(64);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDBusObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBusObjects2Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getX()) + 3000, 475, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBusObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBusObjects2[i].getBehavior("Object3D").setZ(64);
}
}
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("kind2", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene) > 8);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.randomInRange(0, 99) < 35);
}
}
if (isConditionTrue_0) {
{gdjs.Game_32SceneCode.localVariables[1].getFromIndex(0).setNumber(gdjs.randomInRange(0, 2));
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList4(runtimeScene);} //End of subevents
}
gdjs.Game_32SceneCode.localVariables.pop();

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.Game_32SceneCode.GDCoinObjects2});
gdjs.Game_32SceneCode.eventsList6 = function(runtimeScene) {

};gdjs.Game_32SceneCode.eventsList7 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("I", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
const repeatCount2 = 5;
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDCoinObjects2.length = 0;


gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber(repeatIndex2);
let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCoinObjects2Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getX()) + 2200 + gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() * 70, 430, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCoinObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCoinObjects2[i].getBehavior("Object3D").setZ(64);
}
}
}
}
gdjs.Game_32SceneCode.localVariables.pop();

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDShieldPowerupObjects2Objects = Hashtable.newFrom({"ShieldPowerup": gdjs.Game_32SceneCode.GDShieldPowerupObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMagnetPowerupObjects2Objects = Hashtable.newFrom({"MagnetPowerup": gdjs.Game_32SceneCode.GDMagnetPowerupObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDInvincibilityPowerupObjects2Objects = Hashtable.newFrom({"InvincibilityPowerup": gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDoubleCoinPowerupObjects1Objects = Hashtable.newFrom({"DoubleCoinPowerup": gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1});
gdjs.Game_32SceneCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDShieldPowerupObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDShieldPowerupObjects2Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getX()) + 2500, 486, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShieldPowerupObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShieldPowerupObjects2[i].getBehavior("Object3D").setZ(64);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDMagnetPowerupObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMagnetPowerupObjects2Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getX()) + 2500, 486, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMagnetPowerupObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMagnetPowerupObjects2[i].getBehavior("Object3D").setZ(64);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDInvincibilityPowerupObjects2Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getX()) + 2500, 486, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects2[i].getBehavior("Object3D").setZ(64);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDoubleCoinPowerupObjects1Objects, (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) + 2500, 486, "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1[i].getBehavior("Object3D").setZ(64);
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.Game_32SceneCode.GDCoinObjects1});
gdjs.Game_32SceneCode.eventsList9 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).add(2);
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}
elseEventsChainSatisfied = true;
}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Game_32SceneCode.GDCoinObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "sfx_coin.ogg", false, 100, 1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}

}

};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDShieldPowerupObjects1Objects = Hashtable.newFrom({"ShieldPowerup": gdjs.Game_32SceneCode.GDShieldPowerupObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMagnetPowerupObjects1Objects = Hashtable.newFrom({"MagnetPowerup": gdjs.Game_32SceneCode.GDMagnetPowerupObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDInvincibilityPowerupObjects1Objects = Hashtable.newFrom({"InvincibilityPowerup": gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDoubleCoinPowerupObjects1Objects = Hashtable.newFrom({"DoubleCoinPowerup": gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.Game_32SceneCode.GDCoinObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Game_32SceneCode.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCoinObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, 700, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDCoinObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCoinObjects1[i].addForceTowardObject((gdjs.Game_32SceneCode.GDPlayerObjects1.length !== 0 ? gdjs.Game_32SceneCode.GDPlayerObjects1[0] : null), 900, 0);
}
}
}

}


};gdjs.Game_32SceneCode.eventsList11 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Camera"), gdjs.Game_32SceneCode.GDCameraObjects1);
{gdjs.evtsExt__FirstPersonCamera__LookFrom3DObjectEyes.func(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCameraObjects1Objects, "Object3D", "", null);
}
{gdjs.evtsExt__CameraShake__SetDefaultShakingFrequency.func(runtimeScene, 100, null);
}
{gdjs.evtsExt__CameraShake__SetDefaultRotationAmplitude.func(runtimeScene, 2, null);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCameraObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCameraObjects1[i].deleteFromScene(runtimeScene);
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Game_32SceneCode.GDJumpButtonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Game_32SceneCode.GDJumpButtonObjects2);
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDJumpButtonObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDJumpButtonObjects2[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.Game_32SceneCode.GDJumpButtonObjects2[k] = gdjs.Game_32SceneCode.GDJumpButtonObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDJumpButtonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDJumpButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDJumpButtonObjects1_1final.indexOf(gdjs.Game_32SceneCode.GDJumpButtonObjects2[j]) === -1 )
            gdjs.Game_32SceneCode.GDJumpButtonObjects1_1final.push(gdjs.Game_32SceneCode.GDJumpButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDJumpButtonObjects1_1final, gdjs.Game_32SceneCode.GDJumpButtonObjects1);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bus"), gdjs.Game_32SceneCode.GDBusObjects1);
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Game_32SceneCode.GDCarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tram"), gdjs.Game_32SceneCode.GDTramObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCarObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDTramObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDBusObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15211356);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Game_32SceneCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Boundary_Left"), gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Boundary_Right"), gdjs.Game_32SceneCode.GDBoundary_9595RightObjects1);
gdjs.copyArray(runtimeScene.getObjects("Distance_UIText"), gdjs.Game_32SceneCode.GDDistance_9595UITextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDDistance_9595UITextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDDistance_9595UITextObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene))));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBackgroundObjects1[i].setXOffset((( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) / 2);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1[i].setX((( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) - gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1[i].getVariables().getFromIndex(0).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBoundary_9595RightObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBoundary_9595RightObjects1[i].setX((( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) + gdjs.Game_32SceneCode.GDBoundary_9595RightObjects1[i].getVariables().getFromIndex(0).getAsNumber());
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boundary_Left"), gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("FurthestRight_Platform_Ground", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1[i].getX() < (( gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1[k] = gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList3(runtimeScene);} //End of subevents
}
gdjs.Game_32SceneCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}
{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(false);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ObstacleSpawn");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "CoinSpawn");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PowerupSpawn");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "GraceTimer");
}
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("kind", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ObstacleSpawn") > gdjs.evtTools.common.clamp(1.5 - gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene) * 0.025, 0.65, 1.5);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ObstacleSpawn");
}
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber(gdjs.randomInRange(0, 2));
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList5(runtimeScene);} //End of subevents
}
gdjs.Game_32SceneCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "CoinSpawn") > 0.7;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "CoinSpawn");
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("p", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "PowerupSpawn") > 5;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PowerupSpawn");
}
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber(gdjs.randomInRange(0, 3));
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList8(runtimeScene);} //End of subevents
}
gdjs.Game_32SceneCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Game_32SceneCode.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCoinObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShieldPowerup"), gdjs.Game_32SceneCode.GDShieldPowerupObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDShieldPowerupObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDShieldPowerupObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(true);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShieldPowerupObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShieldPowerupObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MagnetPowerup"), gdjs.Game_32SceneCode.GDMagnetPowerupObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMagnetPowerupObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMagnetPowerupObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "MagnetTimer");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMagnetPowerupObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMagnetPowerupObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("InvincibilityPowerup"), gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDInvincibilityPowerupObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(true);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "InvincibleTimer");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DoubleCoinPowerup"), gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDoubleCoinPowerupObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "DoubleTimer");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "MagnetTimer") > 8;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "InvincibleTimer") > 7;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "DoubleTimer") > 10;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "GraceTimer") > 1.2;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Game_32SceneCode.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDCoinObjects1[i].getX() < (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) - 700 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDCoinObjects1[k] = gdjs.Game_32SceneCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDCoinObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDCoinObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bus"), gdjs.Game_32SceneCode.GDBusObjects1);
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Game_32SceneCode.GDCarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tram"), gdjs.Game_32SceneCode.GDTramObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDCarObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDCarObjects1[i].getX() < (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) - 700 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDCarObjects1[k] = gdjs.Game_32SceneCode.GDCarObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDCarObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDTramObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDTramObjects1[i].getX() < (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) - 700 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDTramObjects1[k] = gdjs.Game_32SceneCode.GDTramObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDTramObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBusObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBusObjects1[i].getX() < (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) - 700 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBusObjects1[k] = gdjs.Game_32SceneCode.GDBusObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBusObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDBusObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDCarObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDTramObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCarObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCarObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Game_32SceneCode.GDTramObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTramObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Game_32SceneCode.GDBusObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBusObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShieldPowerup"), gdjs.Game_32SceneCode.GDShieldPowerupObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDShieldPowerupObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDShieldPowerupObjects1[i].getX() < (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) - 700 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDShieldPowerupObjects1[k] = gdjs.Game_32SceneCode.GDShieldPowerupObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDShieldPowerupObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDShieldPowerupObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShieldPowerupObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShieldPowerupObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MagnetPowerup"), gdjs.Game_32SceneCode.GDMagnetPowerupObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMagnetPowerupObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMagnetPowerupObjects1[i].getX() < (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) - 700 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMagnetPowerupObjects1[k] = gdjs.Game_32SceneCode.GDMagnetPowerupObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMagnetPowerupObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMagnetPowerupObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMagnetPowerupObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMagnetPowerupObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("InvincibilityPowerup"), gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1[i].getX() < (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) - 700 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1[k] = gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DoubleCoinPowerup"), gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1[i].getX() < (( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getX()) - 700 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1[k] = gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Coins_UIText"), gdjs.Game_32SceneCode.GDCoins_9595UITextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCoins_9595UITextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCoins_9595UITextObjects1[i].getBehavior("Text").setText("Coins: " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()));
}
}
}

}


{


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(3).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Status_UIText"), gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1[i].getBehavior("Text").setText("SHIELD");
}
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Status_UIText"), gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1[i].getBehavior("Text").setText("MAGNET");
}
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(5).getAsBoolean();
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Status_UIText"), gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1[i].getBehavior("Text").setText("INVINCIBLE");
}
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Status_UIText"), gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1[i].getBehavior("Text").setText("2X COINS");
}
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
gdjs.copyArray(runtimeScene.getObjects("Status_UIText"), gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1[i].getBehavior("Text").setText("");
}
}
elseEventsChainSatisfied = true;
}
}

}

}

};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDDistance_9595UITextObjects1.length = 0;
gdjs.Game_32SceneCode.GDDistance_9595UITextObjects2.length = 0;
gdjs.Game_32SceneCode.GDDistance_9595UITextObjects3.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595RightObjects1.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595RightObjects3.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects2.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects3.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects3.length = 0;
gdjs.Game_32SceneCode.GDCameraObjects1.length = 0;
gdjs.Game_32SceneCode.GDCameraObjects2.length = 0;
gdjs.Game_32SceneCode.GDCameraObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDHazardObjects1.length = 0;
gdjs.Game_32SceneCode.GDHazardObjects2.length = 0;
gdjs.Game_32SceneCode.GDHazardObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595FloatingObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595FloatingObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595FloatingObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects3.length = 0;
gdjs.Game_32SceneCode.GD_9595_9595tempObjects1.length = 0;
gdjs.Game_32SceneCode.GD_9595_9595tempObjects2.length = 0;
gdjs.Game_32SceneCode.GD_9595_9595tempObjects3.length = 0;
gdjs.Game_32SceneCode.GDBuildingObjects1.length = 0;
gdjs.Game_32SceneCode.GDBuildingObjects2.length = 0;
gdjs.Game_32SceneCode.GDBuildingObjects3.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595MagentaObjects1.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595MagentaObjects2.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595MagentaObjects3.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595CyanObjects1.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595CyanObjects2.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595CyanObjects3.length = 0;
gdjs.Game_32SceneCode.GDCoinObjects1.length = 0;
gdjs.Game_32SceneCode.GDCoinObjects2.length = 0;
gdjs.Game_32SceneCode.GDCoinObjects3.length = 0;
gdjs.Game_32SceneCode.GDTramObjects1.length = 0;
gdjs.Game_32SceneCode.GDTramObjects2.length = 0;
gdjs.Game_32SceneCode.GDTramObjects3.length = 0;
gdjs.Game_32SceneCode.GDCarObjects1.length = 0;
gdjs.Game_32SceneCode.GDCarObjects2.length = 0;
gdjs.Game_32SceneCode.GDCarObjects3.length = 0;
gdjs.Game_32SceneCode.GDBusObjects1.length = 0;
gdjs.Game_32SceneCode.GDBusObjects2.length = 0;
gdjs.Game_32SceneCode.GDBusObjects3.length = 0;
gdjs.Game_32SceneCode.GDShieldPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDShieldPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDShieldPowerupObjects3.length = 0;
gdjs.Game_32SceneCode.GDMagnetPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDMagnetPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDMagnetPowerupObjects3.length = 0;
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects3.length = 0;
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects3.length = 0;
gdjs.Game_32SceneCode.GDCoins_9595UITextObjects1.length = 0;
gdjs.Game_32SceneCode.GDCoins_9595UITextObjects2.length = 0;
gdjs.Game_32SceneCode.GDCoins_9595UITextObjects3.length = 0;
gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1.length = 0;
gdjs.Game_32SceneCode.GDStatus_9595UITextObjects2.length = 0;
gdjs.Game_32SceneCode.GDStatus_9595UITextObjects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95956Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95956Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95956Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95957Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95957Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95957Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95957Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95957Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95957Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95956Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95956Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95956Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95957Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95957Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95957Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95956Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95956Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95956Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flower_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flower_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flower_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Awning_9595WideObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Awning_9595WideObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Awning_9595WideObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595UmbrellaObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595UmbrellaObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595UmbrellaObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Umbrella_9595DetailedObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Umbrella_9595DetailedObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Umbrella_9595DetailedObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595OverhangObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595OverhangObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595OverhangObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Overhang_9595WideObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Overhang_9595WideObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Overhang_9595WideObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595AwningObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595AwningObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595AwningObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595GObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595GObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595GObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595HObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595HObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595HObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595KObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595KObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595KObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595IObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595IObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595IObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595GObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595GObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595GObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595JObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595JObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595JObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595LObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595LObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595LObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595MObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595MObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595MObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595NObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595NObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595NObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CenterObjects1.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CenterObjects2.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CenterObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CornerObjects1.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CornerObjects2.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CornerObjects3.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595OverhangObjects1.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595OverhangObjects2.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595OverhangObjects3.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595SideObjects1.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595SideObjects2.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595SideObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDSign_9595BillboardObjects1.length = 0;
gdjs.Game_32SceneCode.GDSign_9595BillboardObjects2.length = 0;
gdjs.Game_32SceneCode.GDSign_9595BillboardObjects3.length = 0;
gdjs.Game_32SceneCode.GDSign_9595HospitalObjects1.length = 0;
gdjs.Game_32SceneCode.GDSign_9595HospitalObjects2.length = 0;
gdjs.Game_32SceneCode.GDSign_9595HospitalObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595SolidObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595SolidObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595SolidObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595B2Objects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595B2Objects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595B2Objects3.length = 0;

gdjs.Game_32SceneCode.eventsList11(runtimeScene);
gdjs.Game_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDDistance_9595UITextObjects1.length = 0;
gdjs.Game_32SceneCode.GDDistance_9595UITextObjects2.length = 0;
gdjs.Game_32SceneCode.GDDistance_9595UITextObjects3.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595RightObjects1.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595RightObjects2.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595RightObjects3.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects1.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects2.length = 0;
gdjs.Game_32SceneCode.GDBoundary_9595LeftObjects3.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects3.length = 0;
gdjs.Game_32SceneCode.GDCameraObjects1.length = 0;
gdjs.Game_32SceneCode.GDCameraObjects2.length = 0;
gdjs.Game_32SceneCode.GDCameraObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDHazardObjects1.length = 0;
gdjs.Game_32SceneCode.GDHazardObjects2.length = 0;
gdjs.Game_32SceneCode.GDHazardObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595FloatingObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595FloatingObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595FloatingObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects3.length = 0;
gdjs.Game_32SceneCode.GD_9595_9595tempObjects1.length = 0;
gdjs.Game_32SceneCode.GD_9595_9595tempObjects2.length = 0;
gdjs.Game_32SceneCode.GD_9595_9595tempObjects3.length = 0;
gdjs.Game_32SceneCode.GDBuildingObjects1.length = 0;
gdjs.Game_32SceneCode.GDBuildingObjects2.length = 0;
gdjs.Game_32SceneCode.GDBuildingObjects3.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595MagentaObjects1.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595MagentaObjects2.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595MagentaObjects3.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595CyanObjects1.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595CyanObjects2.length = 0;
gdjs.Game_32SceneCode.GDNeonLight_9595CyanObjects3.length = 0;
gdjs.Game_32SceneCode.GDCoinObjects1.length = 0;
gdjs.Game_32SceneCode.GDCoinObjects2.length = 0;
gdjs.Game_32SceneCode.GDCoinObjects3.length = 0;
gdjs.Game_32SceneCode.GDTramObjects1.length = 0;
gdjs.Game_32SceneCode.GDTramObjects2.length = 0;
gdjs.Game_32SceneCode.GDTramObjects3.length = 0;
gdjs.Game_32SceneCode.GDCarObjects1.length = 0;
gdjs.Game_32SceneCode.GDCarObjects2.length = 0;
gdjs.Game_32SceneCode.GDCarObjects3.length = 0;
gdjs.Game_32SceneCode.GDBusObjects1.length = 0;
gdjs.Game_32SceneCode.GDBusObjects2.length = 0;
gdjs.Game_32SceneCode.GDBusObjects3.length = 0;
gdjs.Game_32SceneCode.GDShieldPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDShieldPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDShieldPowerupObjects3.length = 0;
gdjs.Game_32SceneCode.GDMagnetPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDMagnetPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDMagnetPowerupObjects3.length = 0;
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDInvincibilityPowerupObjects3.length = 0;
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDDoubleCoinPowerupObjects3.length = 0;
gdjs.Game_32SceneCode.GDCoins_9595UITextObjects1.length = 0;
gdjs.Game_32SceneCode.GDCoins_9595UITextObjects2.length = 0;
gdjs.Game_32SceneCode.GDCoins_9595UITextObjects3.length = 0;
gdjs.Game_32SceneCode.GDStatus_9595UITextObjects1.length = 0;
gdjs.Game_32SceneCode.GDStatus_9595UITextObjects2.length = 0;
gdjs.Game_32SceneCode.GDStatus_9595UITextObjects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95956Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95956Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95956Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_95957Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_95957Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_95957Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95957Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95957Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95957Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95956Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95956Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Moss_95956Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95957Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95957Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95957Objects3.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95956Objects1.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95956Objects2.length = 0;
gdjs.Game_32SceneCode.GDRock_9595Snow_95956Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Autumn_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Dead_9595Snow_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDBirch_9595Tree_9595Snow_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Berries_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Snow_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95955Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_95954Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flower_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flower_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flower_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDCactus_9595Flowers_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Awning_9595WideObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Awning_9595WideObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Awning_9595WideObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595UmbrellaObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595UmbrellaObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595UmbrellaObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Umbrella_9595DetailedObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Umbrella_9595DetailedObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Umbrella_9595DetailedObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595OverhangObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595OverhangObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595OverhangObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Overhang_9595WideObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Overhang_9595WideObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595Overhang_9595WideObjects3.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595AwningObjects1.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595AwningObjects2.length = 0;
gdjs.Game_32SceneCode.GDDetail_9595AwningObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595GObjects1.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595GObjects2.length = 0;
gdjs.Game_32SceneCode.GDLarge_9595Building_9595GObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595HObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595HObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595HObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595KObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595KObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595KObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595IObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595IObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595IObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595GObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595GObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595GObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595JObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595JObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595JObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595LObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595LObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595LObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595MObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595MObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595MObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595NObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595NObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Building_9595NObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CenterObjects1.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CenterObjects2.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CenterObjects3.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDLow_9595Wide_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CornerObjects1.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CornerObjects2.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595CornerObjects3.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595OverhangObjects1.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595OverhangObjects2.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595OverhangObjects3.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595SideObjects1.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595SideObjects2.length = 0;
gdjs.Game_32SceneCode.GDRoof_9595SideObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDSign_9595BillboardObjects1.length = 0;
gdjs.Game_32SceneCode.GDSign_9595BillboardObjects2.length = 0;
gdjs.Game_32SceneCode.GDSign_9595BillboardObjects3.length = 0;
gdjs.Game_32SceneCode.GDSign_9595HospitalObjects1.length = 0;
gdjs.Game_32SceneCode.GDSign_9595HospitalObjects2.length = 0;
gdjs.Game_32SceneCode.GDSign_9595HospitalObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyscraper_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595SolidObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595SolidObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595SolidObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Door_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595BObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595BObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595BObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595AObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595AObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595AObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595DObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595DObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595DObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595CObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595CObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595CObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595FObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595FObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595FObjects3.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595EObjects1.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595EObjects2.length = 0;
gdjs.Game_32SceneCode.GDWall_9595Window_9595EObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595B2Objects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595B2Objects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595Building_9595B2Objects3.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
